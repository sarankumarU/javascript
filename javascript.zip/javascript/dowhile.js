var x= 21;
do
{
console.log("the value of the x is 21");
x++;
}while (x<20);

