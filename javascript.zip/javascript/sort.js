function func() {
    var arr = [2, 5, 8, 1, 4];
    arr.sort(function(a, b) {
        console.log("---->>",a,b)
        console.log(a+2*b)
        return a + 2 * b;
    });
    console.log("<br>");
    console.log(arr);
}
func(); 
 console.log(21 =='21');
