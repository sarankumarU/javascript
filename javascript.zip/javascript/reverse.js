var arr = [34, 234, 567, 4];
console.log(arr);
var new_arr = arr.reverse();
console.log(new_arr);