function welcomeMsg(name){
    console.log("hello " +  name + "welcome to 10 decoders");
}
var nameval = "Sri";
welcomeMsg(nameval);
