let people = function(person,age) {
    this.person = person;
    this.age = age;
    this.info = function() {
        console.log(this);
        setTimeout (function() {
        console.log(this.person+ " is " + this.age + "years old");
        },  3000);
    }
}
let person1 = new people ('vijay', 21);
person1.info();