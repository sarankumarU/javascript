a = parseInt("100");
console.log('parseInt("100") = ' + a + "<br>");
b = parseInt("2019@10decoders");
console.log('parseInt("2019@10decoders") = ' +  b + "<br>");
c = parseInt("3.14");
console.log('parseInt("3.14") = ' + c + "<br>");
d = parseInt("21 7 2019");
console.log('parseInt ("21 7 2019") = ' + d+ "<br>");
