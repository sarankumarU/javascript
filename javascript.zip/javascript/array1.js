var  house ["1BHK" , "2BHK ,[3BHK]" , [4BHK];
house [0] = "1BHK";
house [1] = "2BHK";
house [2] = "3BHK";
house [3] = "4BHK";