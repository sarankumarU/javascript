function func() {
    var arr = [34, 234,567,4];
    console.log(arr.push('jacob',true,23,45));
    console.log("<br>");
    console.log(arr);
}
func();