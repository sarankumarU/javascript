var i=7;
switch (i)
{
    case 0:
    console.log("i is zero.");
    break;
    case 1:
    console.log("i is one.");
    break;
    case 2:
    console.log("i is two.");
    break;
    case 3:
    console.log("i is three.");
    break;
    default:
    console.log("i is greater than 5.");
    break;
}

