function isEven(value){
    console.log(value)
    return value % 2 == 0;
}

function func(){
    var filtered = [11, 24, 36, 51, 32].filter(isEven);
    console.log(filtered);
}
func();