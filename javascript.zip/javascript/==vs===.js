//'=='operator
console.log(21==21);
console.log(21=='21');
console.log('food is love'=='food is love');
console.log(true==1);
console.log(false==0);
console.log(null==undefined);