var i = 10;
{
console.log("i am Not in if")
}
