function add(a, b, callback) {
    console.log(`the sum of ${a} and ${b} is ${a+b}.` +"<br>");
    callback();
}
function disp() {
    console.log('this must be printed after addition');
}
add(5,6,disp);

