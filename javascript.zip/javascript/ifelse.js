var i = 11;
{
console.log("i is greater than 10");

console.log("i is smaller than 10");
}