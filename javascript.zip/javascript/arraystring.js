function func() { 
  
    // Original array 
    var arr = [2, 5, 8, 1, 4]
  
    // Creating a string 
    var str = arr.toString() 
    console.log(str); 
} 
func()